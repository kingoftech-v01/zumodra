
## Company product categories

Add categories of your company's products, goods or services.  
`(ADMIN) Home > Crm > Product categories`

## Company products

Add your company's products, services or goods
(this can be done later by sales managers).  
`(ADMIN) Home > Crm > Products`

