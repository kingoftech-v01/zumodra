from django.apps import AppConfig


class HelpConfig(AppConfig):
    name = 'help'
    default_auto_field = 'django.db.models.AutoField'
